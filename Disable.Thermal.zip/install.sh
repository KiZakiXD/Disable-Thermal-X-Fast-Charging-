SKIPMOUNT=false

PROPFILE=true

POSTFSDATA=true

LATESTARTSERVICE=true

REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"


REPLACE="
"

print_modname() {
  ui_print "________________________________________________"
  ui_print "         DISHABLE THERMAL - FAST CHARGING                "
  ui_print "                K I Z A K I X D                "  
  ui_print "________________________________________________"  
busybox sleep 1
  ui_print "                   "
busybox sleep 1
  ui_print "• Github       : github.com/kizakixd "
  ui_print "• Instagram   : instagram.com/iamkizakixd "
  ui_print "• Bug/Report  : helloiamkizakixd@gmail.com "    
  ui_print "• Version      : Universal Module "
busybox sleep 1
  ui_print "                   "  
  busybox sleep 1
  ui_print " ⚠️ Module is being installed... "
busybox sleep 1
  ui_print "                   "  
  busybox sleep 1
  ui_print " ✔️ Succeed. "
busybox sleep 1
  ui_print "                   "  
  busybox sleep 1
  ui_print "          - RESTART YOUR MOBILE PHONE -                "
busybox sleep 1
  ui_print "                   "      
}


on_install() {
  ui_print "- Extracting module files"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}


set_permissions() {
  # Don't Remove LoL
  set_perm_recursive $MODPATH 0 0 0755 0644
  set_perm $MODPATH/system/bin/P0 0 0 0755 0755
  set_perm $MODPATH/system/bin/P1 0 0 0755 0755
}

